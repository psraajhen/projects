import speech_recognition as sr

r = sr.Recognizer()
with sr.Microphone() as source:
    print("Pranav Speaking :")
    audio = r.listen(source)
    try:
        text = r.recognize_google(audio)
        print("Pranav said : {}".format(text))
    except:
        print("Sorry could not recognize what you said")


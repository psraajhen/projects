import serial #Import Serial Library
from visual import * #Import all the vPython library

arduinoSerialData = serial.Serial('com5', 9600) 
measuringRod = cylinder( radius= .5, length=6, color=color.yellow, pos=(-3,0,0))
lengthLabel = label(pos=(0,1,0), text='Target Distance is: ', box=false, height=30)
while (1==1):  
    rate(20)
    if (arduinoSerialData.inWaiting()>0):  
        myData = arduinoSerialData.readline() 
        print (myData)
        distance = float(myData) 
        measuringRod.length=distance
        myLabel= 'Target Distance is: ' + myData 
        lengthLabel.text = myLabel 
